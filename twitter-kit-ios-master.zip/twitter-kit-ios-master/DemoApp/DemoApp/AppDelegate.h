//
//  AppDelegate.h
//  DemoApp
//
//  Created by Steven Hepting on 4/5/17.
//  Copyright © 2017 Twitter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
