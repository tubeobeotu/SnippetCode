//
//  main.m
//  DemoApp
//
//  Created by Steven Hepting on 4/5/17.
//  Copyright © 2017 Twitter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
